import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

public class MUDController {

    private Player player;
    private boolean running;

    public MUDController(Player player) {
        this.player = player;
        this.running = true;
    }

    public void runGameLoop() {
        Scanner scanner = new Scanner(System.in);

        while (running) {
            System.out.print("> ");
            String input = scanner.nextLine();
            handleInput(input);
        }
    }

    public void handleInput(String input) {
        String[] parts = input.split(" ", 2);
        String command = parts[0];
        String argument = (parts.length > 1) ? parts[1] : "";

        switch (command) {
            case "look":
                lookAround();
                break;
            case "move":
                move(argument);
                break;
            case "pick":
                pickUp(argument);
                break;
            case "inventory":
                checkInventory();
                break;
            case "help":
                showHelp();
                break;
            case "quit":
            case "exit":
                quitGame();
                break;
            default:
                System.out.println("Unknown command.");
        }
    }

    public void lookAround() {
        Room currentRoom = player.getCurrentRoom();
        System.out.println("Room: " + currentRoom.getName());
        System.out.println("Description: " + currentRoom.getDescription());
        System.out.println("Items here: " + currentRoom.getItems());
    }

    public void move(String direction) {
        Room currentRoom = player.getCurrentRoom();
        Room nextRoom = currentRoom.getRoomInDirection(direction);

        if (nextRoom != null) {
            player.setCurrentRoom(nextRoom);
            System.out.println("You move " + direction + ".");
        } else {
            System.out.println("You can't go that way!");
        }
    }

    public void pickUp(String itemName) {
        Room currentRoom = player.getCurrentRoom();
        Item item = currentRoom.getItems(itemName);

        if (item != null) {
            player.addItemToInventory(item);
            currentRoom.removeItem(item);
            System.out.println("You pick up the " + itemName + ".");
        } else {
            System.out.println("No item named " + itemName + " here!");
        }
    }

    public void checkInventory() {
        System.out.println("You are carrying:");
        player.getInventory().forEach(item -> System.out.println("- " + item.getName()));
    }

    public void showHelp() {
        System.out.println("Available commands:");
        System.out.println("look - Look around the current room");
        System.out.println("move <direction> - Move in a specified direction (forward, back, left, right)");
        System.out.println("pick up <item> - Pick up an item from the ground");
        System.out.println("inventory - List the items you're carrying");
        System.out.println("help - Show this help menu");
        System.out.println("quit/exit - Quit the game");
    }

    public void quitGame() {
        running = false;
        System.out.println("Goodbye!");
    }

    public static void main(String[] args) {

        Room room1 = new Room("Room 1", "A small stone chamber");
        Room room2 = new Room("Room 2", "A dark, damp cave");
        Item sword = new Item("sword", "A shiny sword");
        room1.addItem(sword);
        room1.setRoomInDirection("forward", room2);

        Player player = new Player("Player1", room1);

        MUDController controller = new MUDController(player);
        controller.runGameLoop();
    }
}

class Player {
    private String name;
    private Room currentRoom;
    private List<Item> inventory;

    public Player(String name, Room room) {
        this.name = name;
        this.currentRoom = room;
        this.inventory = new ArrayList<>();
    }

    public Room getCurrentRoom() {
        return currentRoom;
    }

    public void setCurrentRoom(Room room) {
        this.currentRoom = room;
    }

    public void addItemToInventory(Item item) {
        inventory.add(item);
    }

    public List<Item> getInventory() {
        return inventory;
    }
}

class Room {
    private String name;
    private String description;
    private List<Item> items;
    private Map<String, Room> directions;

    public Room(String name, String description) {
        this.name = name;
        this.description = description;
        this.items = new ArrayList<>();
        this.directions = new HashMap<>();
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public void addItem(Item item) {
        items.add(item);
    }

    public void removeItem(Item item) {
        items.remove(item);
    }

    public List<Item> getItems() {
        return items;
    }

    public void setRoomInDirection(String direction, Room room) {
        directions.put(direction, room);
    }

    public Room getRoomInDirection(String direction) {
        return directions.get(direction);
    }

    public Item getItems(String itemName) {
        return null;
    }
}

class Item {
    private String name;
    private String description;

    public Item(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }
}
